# angryBirdsStage2
Angry Birds stage 2 with Class Inheritance and Images
